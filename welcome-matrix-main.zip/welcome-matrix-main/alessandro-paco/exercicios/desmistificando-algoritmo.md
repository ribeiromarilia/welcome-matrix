- Diagrama estruturado

- Fluxograma 

- Pseudocódigo

- Ações executadas

- Algoritmo em diagrama estruturado, sendo convertido em fluxograma.

- Diagrama estruturado/Fluxograma sendo convertido em Pseudocódigo.

- Diagrama estruturado/Fluxograma/Pseudocódigo tendo a quantidade de ações executadas.

- Pelo pseudocódigo é possível fazer engenharia reversa.


- Algoritmo não estruturado/Anomalia, onde não é possível separar os lados V e F, uma vez que a mesma instrução é utilizada por ambos os lados.

- Portas Lógicas, onde utiliza o operador do prod lógico e o de inversão.

	Nand -> Nega o resultado do AND

	Nor -> Nega o resultado do OR