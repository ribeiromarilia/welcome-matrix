## Exercício 1:

(A) "Manaus é a capital do estado da Bahia"


## Exercício 2:

A-) Não está Frio

B-) Está frio e está chovendo

C-) Está frio ou está chovendo

D-) Está chovendo se e somente se está frio

E-) Se está frio então não está chovendo

F-) Não está frio e não está chovendo

G-) Está frio ou não está chovendo

H-) Está frio e não está chovendo Se não está chovendo então está frio


## Exercício 3:

A-)P∨Q^R

B-)P^Q∨¬P^R

C-)¬P^¬R

D-)¬Q∨R^¬P


## Exercício 4:

A-)

|P|Q|(|¬P|∧|¬Q|)|
|-|-|-|-|-|-|-|
|V|V| |F|V|F|F|V|
|V|F| |F|V|F|V|F|
|F|V| |V|F|F|F|V|
|F|F| |V|F|V|V|F|

    
B-)

|P|Q|¬|(|P|∨|Q)|
|-|-|-|-|-|-|-|
|V|V| |F|V|V|V|
|V|F| |F|V|V|F|
|F|V| |F|F|V|V|
|F|F| |V|F|F|F|


D-)

|P|Q|R||(P|∧|Q)|∨|¬|(P|∧|R)|
|-|-|-|-|-|-|-|-|-|-|-|-|
|V|V|V|	|V|V|V|V|F|V|V|V|
|V|V|F|	|V|V|V|V|V|V|F|F|
|V|F|V|	|V|F|F|F|F|V|V|V|
|V|F|F|	|V|F|F|V|V|V|F|F|
|F|V|V|	|F|F|V|V|V|F|F|V|
|F|V|F|	|F|F|V|V|V|F|F|F|
|F|F|V|	|F|F|F|V|V|F|F|V|
|F|F|F|	|F|F|F|V|V|F|F|F|
  