# alessandro-paco

`git clone` = Comando para clonar repositórios github

`code .` = Abre o reposítorio no VsCode

`git add` = Adiciona um arquivo ou todos (Utilizando .) para o commit

`git commit -m` = Adiciona descrição do commit

`git push` = Envia o commit para o reposítorio (Adicionar origin name em casos específicos)

`git pull` = Puxa os commits para o reposítorio local (Adicionar origin name em casos específicos)

`git checkout -b` = Cria uma nova branch

`git checkout name` = Muda para a branch selecionada (Trocar 'name')

`git merge master` = Enquanto na branch faz o merge com a Master

`git config --global user.email "user@user.com"` = Configura o usuário padrão para utilizar o git no ambiente global

`git config --global user.name "Username"` = Configura o nome do usuário padrão para utilizar o git no ambiente global

`git log`= Exibe o histórico do git

