Todos os comandos tem sua utilidade.
Por�m alguns usados com maior frequencia.

git init para iniciar um novo projeto;
git clone para copiar o repositorio do GitHub para o meu computador;
git remote add para associar os arquivos locais com os arquivos do repositorio do GitHub;
git pull para atualizar os arquivos locais em rela��o ao repositorio no GitHub;
git status para verificar os arquivos;
git add . para adicionar ao stage (antes de dar um "commit");
git commit -m para salvar uma nova vers�o do projeto;
git push -u para enviar os ficheiros locais para o repositorio no GitHub.

Pelo que percebi os mais utilizados com maior frequencia s�o:
git status para verificar os arquivos
git add . para adicionar os arquivos no stage
git commit para comentar as mudan�as;
git push para publicar os arquivos locais com o repositorio do GitHub

E pelo que andei estudando a parte, tem alguns comandos S.O.S que acho que pode salvar nossas vidas.

Particularmente gostei do:
git clean �df
git checkout -- .
que desfaz todo o ultimo commit caso tenha dado tudo errado.
