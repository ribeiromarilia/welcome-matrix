Comandos basicos Git


git init - para criar um novo repositorio local na pasta do projeto;

git status - verifica os arquivos/diretorios armazenados no contaneir;

git add *  - adiciona todos os arquivos ou pastas que foram criados ou modificados;

git commit -m "comentario" - identifica e armazena o container no repositorio local;

git log - exibe historico

git rm "nome do arquivo" - remove arquivo

git push - envia arquivos/diretorio para repositorio remoto

git pull - atualiza arquivos no branch atual

git fecth - busca alterações , mas nÃo aplica no branch atual

git clone - clona repositorio remoto

git branch - listar branch




clear - limpa a tela

touch" nome do arquivo".'tipo do arq' - cria arquivos

code.- abre vs code
