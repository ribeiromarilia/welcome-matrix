Git - Lista de comandos

Segue abaixo, a lista de comandos fundamentais que identifiquei e utilizo no dia a dia.

git clone - Clone para um repositório.
git pull - Atualiza os arquivos com a última versão comitada. 
git status - Consultar o estado do diretório. 
git checkout - Criar um branch localmente.
git push - Envia modificações do repositorio local.
git stash - Arquiva alterações realizadas por um período, "ignorando" os conflitos.
git stash list - Retorna todas as stashes criadas.
