Comandos GitHub


git init 
Inicializa o git no reposit�rio em quest�o;

git status
verifica em qual branch estou e se h� algum arquivo (e quais) para ser commitado;

git add
adiciona o (s) arquivo (s) em nossa �rvore de trabalho.

git branch
Listar, criar ou excluir branches

git checkout
muda a branch de desenvolvimento em que estamos;




Comandos Git Bash


dir = diret�rio, lista todas as pastas contidas no diret�rio pedido. (ls no Linux).

cd = change directory, usado para navegar entre as pastas. (cd/ avan�a) (cd .. retorna).

cls = clear screen, usado para limpar o terminal. (clear no Linux).

mkdir = make directory, comando usado para criar uma pasta.

echo = printa um comando, ex: echo hello retorna hello no Comand

> = redirecionador de fluxo.

del = deleta apenas arquivos no Windows (rm no Linux)

seta do teclado para cima = navega entre o hist�rico de comandos digitados anteriormente.

rmdir = remove directory, usado para remover todo reposit�rio de uma pasta. (rf no Linux)