


# Curso Matrix

## Módulo Nivelamento

## Matéria Git e GitHub


Listagem de alguns dos comandos que identifiquei como sendo os fundamentais para o desempenho do meu trabalho no dia-a-dia.

| Comando | Descrição |
| ------ | ------ |
|git init|para inicializar um repositório git na raiz da pasta|
|git clone|para baixar o código-fonte existente de um repositório remoto|
|git status|para fornece todas as informações necessárias sobre o branch atual|
|git add|para adicionar os arquivos em nossa repositório de trabalho|
|git checkout|para mudar a branch de desenvolvimento em que estamos|
|git branch|para criar, listar e excluir branch|
|git push|para enviar e salvar suas confirmações no repositório remoto|
|git pull|para obter atualizações do repositório remoto|
|git commit -m|para adicionar uma descrição no commmit|
|git log| para exibir o histórico|



_Atualizado em 16/03/2021_

