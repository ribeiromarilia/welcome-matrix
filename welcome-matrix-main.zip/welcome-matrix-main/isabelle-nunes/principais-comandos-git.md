
git init = utilizado para criar um novo repositório

git remote add origin = utilizado para conectar o repositório local e o repositório remoto. (origin é o apelido do repositório local utilizado)

git clone = utilizado para clonar um repositório e fazer alterações

git pull = as alterações realizadas no repositório remoto são puxadas para o repositório local 

git push = envia as informações do repositório local para o repositório remoto

git add = seleciona os arquivos e pastas a serem monitorados pelo git

git commit = utilizado para publicar as alterações no histórico do repositório remoto

git branch = cria um novo branch

git chekout = ativa o branch criado

git status = utilizado para verificar qual branch está ativo no momento

git merge = utilizado para que o dono do repositório, após aprovar, consiga incluir os pull requests enviados por terceiros em seu projeto original
