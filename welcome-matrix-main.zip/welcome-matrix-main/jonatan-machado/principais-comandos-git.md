# Exercício fork repositório welcome-matrix

> O conteúdo desse exercício está no google drive e pode ser acessivel através do link [Google Drive](https://docs.google.com/document/d/1PPaDeL7wzb-jLWAceqKiSQCwBzD9ILY4A6Bs3dIxLuI/edit?usp=sharing)

## Git Alias

git config --global alias.st status

git config --global alias.lg 'log --all --graph --decorate --oneline --abbrev-commit'

git config --global alias.ac '!git add -A && git commit'

git config --global alias.ci commit

git config --global alias.co checkout

git config --global alias.br branch

git config --global alias.fixup 'commit --all --amend --no-edit'
