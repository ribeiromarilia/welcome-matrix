Repositórios; Contém todos os arquivos e processos do projeto, como documentação, imagens, e códigos do projeto.
Issues; Usado para discutir ideias, mudanças, rastrear Bugs e Futures Request. Pode ser designado para uma pessoa específica. Promove discussões e colaboração para resolução dos problemas em grupo.
Ppull Requests; Apresenta as alterações de arquivos e deleções que o responsável pelo projeto deseja realizar na aplicação. Usado para resolução de Issues .
      	- Merge Pull Request;  Fazer a fusão das alterações aprovadas pela equipa.
Watch; Apresenta todas as notificações com relação ao repositório. Todas as alterações realizadas nele, como novo Isseu, Pull Resquest or comment são adicionados. Também é notificado quando um Pull Resquest é fechado e fundido.
Star; Recurso para encontrar o repositório mais fácil.
Explore;  Input de pesquisa para encontrar projeto em GitHub
 
Assigned; Designação do responsável para a tarefa no repositório.
 
Branches; Funcionalidade de fluxo de trabalho para desenvolver e propor novas soluções para o projeto sem comprometer a base principal.
 
 Commit; Comando para fazer realizar as alterações no branche como, alteração de código, envio de arquivos e etc.
