
<h1  align="center">Principais Comandos Git/GitHub</h1>

git init => novo repositório.

git status => verificar o estado do arquivo e diretório.  

git add nome_do_arquivo.txt =>adicionar um arquivo ou diretório.
	OBS: pode colocar => git add . - para adicionar todos os arquivos.

git commit nome_do_arquivo.txt “informações sobre a versão” => comitar um arquivo e informar alterações nesta versão.

git rm meu_arquivo.txt => remover o arquivo ou pode colocar o -r para remover o repositório: git rm -r nome_repositório.txt

git log --stat => serve para mostrar o histórico e informações como comentários, auto, data, etc…

git remote => exibir o repositório remoto. 

git push => enviar o arquivo para o repositório remoto.

git pull => atualizar arquivos na branch atual.

git merge sua-branch => fazer a junção dela com sua branch de origem para que suas alterações sejam incluídas no projeto
