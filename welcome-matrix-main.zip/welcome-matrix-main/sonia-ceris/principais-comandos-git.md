git config – global user.name “[user]” - Configurar o nome do user para os commits 
git config – global user.email “[email]” - Configurar o email do user para os commits 
git init [nome_proj] – Criar um novo projecto/repositório 
git clone [url] - Download de um repositório 
git rm [nome_arquivo] - Apagar um arquivo 
git mv [nome_arquivo_original] [nome_arquivo_renomeado] - Renomear um arquivo existente e faz commit 
git reset [commit] - Revert do último commit 
git reset –hard [commit] - Revert de todas as alterações para um commit específico 
git branch - Listagem de todos os branches de um repositório local git branch [nome_branch] - Criar um novo branch 
git checkout [nome_branch] - Altera para o branch especificado e actualiza o directório git merge [branch] - Merge entre um branch específico e o actual 
git log - Listagem do histórico do branch actual 
git diff [branch_1] [branch_2] - Mostra as diferenças entre os 2 branches git show [commit] - Mostra as mudanças efectuadas no commit 
git add - Adicionar arquivos no diretório local 
git status - Mostra os arquivos alterados, ou arquivos novos que ainda não foram guardados 
git push - Envia as alterações efectuadas para o repositório principal git remote –v - Lista os repositórios remotos configurados 
git remote add origin <”IP”> - Ligação remota a um servidor git tag - Marca notas específicas (comentários) 
git grep “teste” - Procura a palavra escolhida nos arquivos git archive –format = xpto.rar - Converte num arquivo .rar 
git bisect good - Valida entre todos os commits, aqueles que estão correctas e marca como “bom” 
git bisect bad - Valida entre todos os commits, aqueles que não estão correctas e marca como “bad” 
git commit nome.txt - Efectua o commit do ficheiro git commit nome.txt nome1.txt - Efectua o commit de mais que 1 ficheiro 
git pull - Repor o repositório local com dados do repositório remoto
