git help – é usado para pedir ajuda.

git pull – é usado para atualizar os arquivos no branch  do repositório remoto. 

git tag - criando uma tag leve.

git branch – é o comando usado para criar, listar e excluir branches. 

git merge – é usado na etapa final para mesclar as branches quando você conclui um processo de desenvolvimento que esta funcionando perfeitamente. 

git commit – comando que define um ponto de verificação em algum processo de desenvolvimento que esteja fazendo permitindo voltar mais tarde se for necessário para alterando mensagens. 

git push – é o comando usado para criar branch localmente, e para enviar e salvar sua confirmações da nova brach para o repositório remoto. 

git checkout – é principalmente usado para alterar de um brach para o outro, porem podemos utiliza-lo para verificar arquivos e commits.
 
git add – usamos para incluir as alterações de um arquivo em nosso commit. 

