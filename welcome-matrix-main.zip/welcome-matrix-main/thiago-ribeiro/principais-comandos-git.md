git status -> Para verificar as alterações feitas em seu documento
git add . -> Para adicionar todas as alterações feitas e prepará-las para o commit
git commit -m -> Para salvar as alterações feitas em seu repositório local
git push -> Para enviar as alterações feitas para seu repositório remoto, e deixá-la acessível a outros colaboradores