```
git clone
git init
git add <name_of_the_file>
git add .
git commit -m “explanation about this commit”
git push origin master
git push origin <name of the repo>
git pull
git fetch
git remote -v
git remote add origin <address of the cloud repo for being the origin>
```
