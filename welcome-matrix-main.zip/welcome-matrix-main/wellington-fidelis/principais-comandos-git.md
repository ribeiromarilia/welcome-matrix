Estou estudando inglês e pretendo escrever tudo em inglês para treinar. Se não for pedir muito, comentar os erros para que eu possa pesquisar a melhor escrita, não precisa corrigir, pois, vai usar o tempo dos senhores.
Agradeço desde já.

# Main Commands Git

## git add
I use “git add .” to prepare the files to stage area all the files modified.
## git commit -m “message”
I used this command to send all files that have been prepared to stage area, waiting for the command push
## git status
When I use this command I can see the file that wasn't committed to the stage area and which was it.
## git push origin <branch in use>
Recently I have been trying to use the merge and pull request commands, than I create branch to use to developer and the main branch to save the project without bugs. So, when i push file to the remote repository, I choose the branch, if I am already working on it I just type git push.
## git pull origin <branch that I want to work>
This command I use less than the others because when I clone the projects I already clone with the branch to the development
## git clone --branch <branch that I want to work> <remote repository .git>
Command to clone the remote repository to the local, ours PCs. I usually clone the remote repository with the branch that I will work.
## git branch
I use git branch to see what branch are able on local. Git branch -a to create a local branch to work. 
## git checkout <name of branch to switch>
Git checkout is used to change branches that are able. 
## pull request
I still have not learned to use in command line, only by browser.
## git merge
This is the same problem with pull request.
