
Criar novo repositório: git init

É um comando para baixar o código-fonte existente de um repositório remoto: git clone 

Novo branch: git branch <nome-do-branch>

Listar branch: git branch ou git branch --list

Excluindo branch: git branch -d <nome-da-branch>

Trocar de branch: git checkout <nome-da-branch>

Verifica alterações do branch: git status

Adicionar arquivo específico alterado no branch (prepara para commit): git add <arquivo>

Adiciona todos os arquivos alterados de uma única vez  (prepara para commit): git add .

Commitar um arquivo alterações: git commit -m "Descrição da alteração"

Git log - Exibir histórico: git log 

Enviar arquivos/diretórios para o repositório remoto: git push <remote> <nome-do-branch>

Obter atualizações do repositório remoto: git pull <remote>

